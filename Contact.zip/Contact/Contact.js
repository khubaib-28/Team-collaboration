document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Stop default form submission
        alert("Thank you! Your message has been sent.");
        form.reset(); // Clear the form fields
    });
});
