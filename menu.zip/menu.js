document.addEventListener("DOMContentLoaded", function () {
    const addToCartButtons = document.querySelectorAll(".add-to-cart");
    const cartContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");

    let cart = [];

    // Add to cart button click
    addToCartButtons.forEach(button => {
        button.addEventListener("click", function () {
            const price = parseInt(this.getAttribute("data-price"));
            const name = this.getAttribute("data-name");

            const existingItem = cart.find(item => item.name === name);
            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({ name, price, quantity: 1 });
            }
            updateCartUI();
        });
    });

    // Update cart display
    function updateCartUI() {
        cartContainer.innerHTML = "";
        let total = 0;

        cart.forEach((item, index) => {
            total += item.price * item.quantity;

            const itemRow = document.createElement("div");
            itemRow.classList.add("cart-item");
            itemRow.innerHTML = `
                <span>${item.name}</span>
                <span>Rs ${item.price}</span>
                <span>Qty: 
                    <button class="decrease" data-index="${index}">-</button> 
                    ${item.quantity} 
                    <button class="increase" data-index="${index}">+</button>
                </span>
                <button class="remove" data-index="${index}">Remove</button>
            `;
            cartContainer.appendChild(itemRow);
        });

        totalPriceElement.textContent = total;
        localStorage.setItem("cartTotal", total)

        // Attach event listeners for quantity changes and remove
        document.querySelectorAll(".increase").forEach(btn => {
            btn.addEventListener("click", function () {
                const idx = this.getAttribute("data-index");
                cart[idx].quantity++;
                updateCartUI();
            });
        });

        document.querySelectorAll(".decrease").forEach(btn => {
            btn.addEventListener("click", function () {
                const idx = this.getAttribute("data-index");
                if (cart[idx].quantity > 1) {
                    cart[idx].quantity--;
                }
                updateCartUI();
            });
        });

        document.querySelectorAll(".remove").forEach(btn => {
            btn.addEventListener("click", function () {
                const idx = this.getAttribute("data-index");
                cart.splice(idx, 1);
                updateCartUI();
            });
        });
    }
});

