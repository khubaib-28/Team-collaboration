// Get total from localStorage (menu page se set kiya hua)
let totalAmount = parseFloat(localStorage.getItem("cartTotal")) || 0;
document.getElementById("totalAmount").textContent = totalAmount;

document.getElementById("paymentForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let name = document.getElementById("name").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let paymentMethod = document.getElementById("paymentMethod").value;
    let amount = parseFloat(document.getElementById("amount").value);
    let message = document.getElementById("message");

    // Field validation
    if (!name || !phone || !paymentMethod || isNaN(amount)) {
        message.textContent = "Please fill all fields!";
        message.style.color = "red";
        return;
    }

    // Payment checks
    if (amount < totalAmount) {
        message.textContent = "Insufficient amount!";
        message.style.color = "red";
    } 
    else if (amount > totalAmount) {
        message.textContent = "Payment Successful. Please take your order and remaining change from counter, and don't forget to review our service.";
        message.style.color = " #ffcc00";
    } 
    else { // amount === totalAmount
        message.textContent = "Payment Successful. Please take your order from counter and don't forget to review our service.";
        message.style.color = " #ffcc00";
    }
});

